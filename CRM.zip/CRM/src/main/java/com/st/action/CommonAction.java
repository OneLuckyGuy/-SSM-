package com.st.action;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.st.service.UserService;
 //跳转登录页面
@Controller
public class CommonAction {
	 @Autowired
	 UserService userSer;
	 //跳转到登录界面
	@RequestMapping("login")
	public String login() {
		return "login";
	}
	@RequestMapping("cuslogin")
	public String cuslogin() {
		return "cuslogin";
	}
	//点击登录
	@RequestMapping("loginaction")
	public String loginaction(@RequestParam Map params,HttpSession session) {
		int  b=userSer.login(params,session);
		if(b==1) {
			return "system";
		}else if(b==2) {
			return "cussystem";
		}else {
			return "login";
		}
		
	}
	
}
