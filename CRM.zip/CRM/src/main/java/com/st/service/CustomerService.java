package com.st.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.st.dao.CustomerDao;
import com.st.util.ParamsUtil;

@Service
public class CustomerService {
	@Autowired
	CustomerDao cusDao;
	public int getCount(Map params) {
		return cusDao.getCount(params);
	}
	public List customer_list(Map params) {
		ParamsUtil.page(params);
		return cusDao.customer_list(params);	
	}
	public int getfreeCount(Map params) {
		return cusDao.getfreeCount(params);
	}
	public List free_rooms_list(Map params) {
		ParamsUtil.page(params);
		return cusDao.free_rooms_list(params);	
	}
	public void customer_save(Map params) {
		ParamsUtil.uuid(params);
		String str=params.get("private")+"";
		if("null".equals(str)) {
			params.put("loginUserID", "");
			ParamsUtil.state(params, 1);
		}else {
			ParamsUtil.loginUserID(params, null);
			ParamsUtil.state(params, 2);
		}
		
		cusDao.customer_save(params);
	}
	public void customer_del_more(Map params) {
		ParamsUtil.arr_str(params, "customerids");
		cusDao.customer_del_more(params);
		
	}
	public void customer_update(Map params) {
		cusDao.customer_update(params);
	}
	public void customer_del(Map params) {
		cusDao.customer_del(params);
	}
	public int getPublicCount(Map params) {
		return cusDao.getPublicCount(params);
	}
	public List customer_public_list(Map params) {
		ParamsUtil.page(params);
		return cusDao.customer_public_list(params);
	}
	public void customer_private(@RequestParam Map params) {
		ParamsUtil.state(params, 1);
		//当前登录用户
		ParamsUtil.loginUserID(params, null);
		cusDao.customer_private(params);
		
	}
	
	public int getPrivateCount(Map params ) {
		ParamsUtil.loginUserID(params, null);
		return cusDao.getPrivateCount(params);
	}
	public List customer_private_list(Map params ) {
		ParamsUtil.page(params);
		ParamsUtil.loginUserID(params, null);
		return cusDao.customer_private_list(params);
	}
	public List cus_customer_private_list(Map params,HttpSession session ) {
		ParamsUtil.page(params);
		ParamsUtil.Customer_id(params,session);
		return cusDao.cus_customer_private_list(params,session);
	}
	public void customer_public(@RequestParam Map params ) {
		ParamsUtil.state(params, 0);
		//当前登录用户
		ParamsUtil.loginUserID(params, null);
		cusDao.customer_public(params);
		
	}
	public void customer_book(Map params) {
		cusDao.customer_book(params);
	}
	public void customer_checkin(Map params) {
		cusDao.customer_checkin(params);
	}
	public void customer_checkout(Map params) {
		cusDao.customer_checkout(params);
	}
	
}
