package com.st.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.st.dao.VisitDao;
import com.st.util.ParamsUtil;

@Service
public class VisitService {
	@Autowired
	VisitDao visitDao;
	public void visit_save(Map params) {
		ParamsUtil.uuid(params);
		ParamsUtil.loginUserID(params, null);
		ParamsUtil.payment(params);
		visitDao.visit_save(params);
		
	}
	public List visitlog_list(Map params) {
		 return visitDao.visitlog_list(params);
	}
	public void ann_save(Map params) {
		visitDao.ann_save(params);
		
	}
	public List ann_list(Map params) {
		 return visitDao.ann_list(params);
	}
	

}
