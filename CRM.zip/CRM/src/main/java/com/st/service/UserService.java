package com.st.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.st.dao.UserDao;
import com.st.util.MD5;
import com.st.util.ParamsUtil;
@Service
public class UserService {
	@Autowired
	UserDao user_dao;


	public void test() {
		List list=user_dao.test();
		for(Object obj:list) {
			System.out.println(obj);
		}
	}
	public List user_list(Map params) {
		//计算出每页要显示的数据开始的下标，保存到params中去
		ParamsUtil.page(params);
		return user_dao.user_list(params);
		
	}

	public int getCount(Map params) {
		return user_dao.getCount(params);
	}
	public void user_del(Map params) {
		user_dao.user_del(params);
	}
	public String user_save(Map params) {
		//params缺少参数
		//uuid
		ParamsUtil.uuid(params);
		//user_loginpass
		String initpass=ParamsUtil.initpass(params,params.get("uuid").toString());
		user_dao.user_save(params);
		return initpass;
	}
	public void user_update(Map params) {
		user_dao.user_update(params);
	}
	public void user_del_more (Map params) {
		//要执行删除
		//userids=1,2,
		//in('','','')
		//参数{}
		ParamsUtil.arr_str(params,"userids");
		user_dao.user_del_more(params);
	}
	public int login(Map params,HttpSession session) {
		//根据用户名查询数据表中是否有该用户的信息
		List list =user_dao.user_login(params);
		List cuslist = user_dao.cus_login(params);
		if(list!=null&&list.size()==1) {
			Map user=(Map)list.get(0);
			//有：匹配密码是否正确  正确登陆成功
			String user_salt_i=user.get("User_id").toString();
			int hashIterations=Integer.parseInt(user_salt_i.substring(user_salt_i.length()-4));
			String md5pass=MD5.md5(params.get("login_pass").toString(), user_salt_i, hashIterations);
			if(md5pass.equals(user.get("User_loginpass"))){
				session.setAttribute("loginuser", user);
				return 1;
			}
		
		}else if(cuslist!=null&&cuslist.size()==1) {
			Map cus=(Map)cuslist.get(0);
			//有密码
			if(params.get("login_pass").equals(((Map)(cuslist.get(0))).get("Customer_pass"))){
				session.setAttribute("logincus", cus);
				return 2;
			}
		}
		return 0;
		
	}
	public void editpass(Map params,HttpSession session) {
		Map user=(Map)session.getAttribute("loginuser");
		String user_salt_i=user.get("User_id").toString();
		int hashIterations=Integer.parseInt(user_salt_i.substring(user_salt_i.length()-4));
		String md5pass=MD5.md5(params.get("User_newpass").toString(), user_salt_i, hashIterations);
		params.put("newpass",md5pass);
		params.put("User_id",user_salt_i);
		user_dao.editpass(params);
	}
}
