
package com.st.dao;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Repository;

@Repository
public interface CustomerDao {
	int getCount(Map params);

	List customer_list(Map params);

	void customer_save(Map params);

	void customer_del_more(Map params);

	void customer_update(Map params);

	void customer_del(Map params);

	List customer_public_list(Map params);

	int getPublicCount(Map params);

	void customer_private(Map params);

	List customer_private_list(Map params);
	
	List cus_customer_private_list(Map params,HttpSession session);

	int getPrivateCount(Map params);

	void customer_public(Map params);

	int getfreeCount(Map params);

	List free_rooms_list(Map params);

	void customer_book(Map params);

	void customer_checkin(Map params);

	void customer_checkout(Map params);

}
