package com.st.util;

import org.apache.shiro.crypto.hash.SimpleHash;

public class MD5 {

	public static String md5(String src,String salt,int hashIterations){
		//设置加密次数
		SimpleHash sh=new SimpleHash("md5",src,salt,hashIterations);
		String md5pass = sh.toHex();

		return md5pass;
		
	}

}
