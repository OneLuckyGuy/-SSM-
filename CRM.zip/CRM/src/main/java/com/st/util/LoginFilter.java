package com.st.util;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * 验证用户是否登录，如果登录可以正常访问，没有登录跳转到登录页面
 * 
 *
 */
public class LoginFilter extends HttpFilter{

	@Override
	protected void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		//session中保存了loginuser属性，说明已经登录，否则，没有登录
		HttpSession session =request.getSession();
		Object user=session.getAttribute("loginuser");
		Object cus=session.getAttribute("logincus");
		if(user!=null||cus!=null) {
			//有值已登录
			super.doFilter(request, response, chain);
		}else {
			//转发到login
			//request.getRequestDispatcher("login").forward(request, response);
			//重定向
			String path = request.getContextPath();
			String basePath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()
					+ path + "/";
			response.sendRedirect(basePath+"login");
		}
	}
}
