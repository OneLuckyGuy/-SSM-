/*
Navicat MySQL Data Transfer

Source Server         : 123
Source Server Version : 80020
Source Host           : localhost:3306
Source Database       : stcrm

Target Server Type    : MYSQL
Target Server Version : 80020
File Encoding         : 65001

Date: 2020-06-11 12:24:28
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for crm_customer
-- ----------------------------
DROP TABLE IF EXISTS `crm_customer`;
CREATE TABLE `crm_customer` (
  `Customer_id` varchar(40) COLLATE utf8_bin NOT NULL COMMENT '主键',
  `Customer_name` varchar(17) COLLATE utf8_bin DEFAULT NULL COMMENT '客户名',
  `Customer_tel` varchar(17) COLLATE utf8_bin DEFAULT NULL COMMENT '联系电话',
  `Customer_addr` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '地址',
  `Customer_state` int DEFAULT NULL COMMENT '状态是否是公海客户客户0/公海客户,五业务员跟单1/跟单客户,由业务员负责练习',
  `Customer_user_id` varchar(40) COLLATE utf8_bin NOT NULL COMMENT '跟单业务员主键',
  PRIMARY KEY (`Customer_id`,`Customer_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of crm_customer
-- ----------------------------

-- ----------------------------
-- Table structure for crm_user
-- ----------------------------
DROP TABLE IF EXISTS `crm_user`;
CREATE TABLE `crm_user` (
  `User_id` varchar(40) COLLATE utf8_bin NOT NULL COMMENT '主键',
  `User_loginname` varchar(17) COLLATE utf8_bin DEFAULT NULL COMMENT '登录名',
  `User_loginpass` varchar(17) COLLATE utf8_bin DEFAULT NULL COMMENT '登陆密码',
  `User_realname` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '真名',
  PRIMARY KEY (`User_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of crm_user
-- ----------------------------

-- ----------------------------
-- Table structure for crm_visit_way
-- ----------------------------
DROP TABLE IF EXISTS `crm_visit_way`;
CREATE TABLE `crm_visit_way` (
  `Way_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `Way_name` varchar(17) COLLATE utf8_bin DEFAULT NULL COMMENT '回访名称',
  PRIMARY KEY (`Way_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of crm_visit_way
-- ----------------------------

-- ----------------------------
-- Table structure for crm_visitlog
-- ----------------------------
DROP TABLE IF EXISTS `crm_visitlog`;
CREATE TABLE `crm_visitlog` (
  `Visit_id` varchar(40) COLLATE utf8_bin NOT NULL COMMENT '主键',
  `Visit_time` varchar(17) COLLATE utf8_bin DEFAULT NULL,
  `Visit_user_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `Visit_customer_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `Visit_customer_info` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `Visit_payment` int DEFAULT NULL COMMENT '是否付款',
  `Visit_money` int DEFAULT NULL,
  `Crm_visit_way_id` varchar(40) COLLATE utf8_bin DEFAULT NULL COMMENT '回访方式',
  PRIMARY KEY (`Visit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of crm_visitlog
-- ----------------------------
